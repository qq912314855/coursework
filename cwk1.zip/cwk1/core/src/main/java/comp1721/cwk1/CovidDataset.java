package comp1721.cwk1;

public class CovidDataset {
  // TODO: Write stub for size()

  // TODO: Write stub for getRecord()

  // TODO: Write stub for addRecord()

  // TODO: Write stub for dailyCasesOn()

  // TODO: Write stub for readDailyCases()

  // TODO: Write stub for writeActiveCases()
}
