package comp1721.cwk1;

public class CaseRecord {
  // TODO: Write stub for constructor

  // TODO: Write stubs for four getter methods

  // TODO: Write stub for totalCases()
  
  // TODO: Write stub for toString()
}
