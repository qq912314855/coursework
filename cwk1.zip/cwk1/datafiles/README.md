# Coursework 1 Data Files

`2020-daily.csv` is a file containing daily records of positive COVID-19
tests at the University of Leeds for staff, students and other individuals,
spanning the period 28 September 2020 to 13 December 2020.

`2021-daily.csv` is a file containing equivalent data for January 2021.

The `testing` subdirectory contains CSV files used by the tests.  **Do not
remove this directory, and do not remove or alter any of the files that
it contains!**  If you change anything here, it will break some of the tests.
