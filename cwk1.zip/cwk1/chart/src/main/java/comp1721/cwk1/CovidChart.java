package comp1721.cwk1;

// Implement your solution to the Advanced task here
// (Note: the class must be named CovidChart)
